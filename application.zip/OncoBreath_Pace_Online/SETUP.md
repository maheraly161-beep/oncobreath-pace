# Running OncoBreath Pace

Extract the ZIP before opening any files. Keep the app, data, evidence and model folders together.

On the preparation computer, double-click START_ONCOBREATH_PACE.cmd. It opens http://127.0.0.1:8767/ and uses the installed local runtime. CHECK_SETUP.cmd reports prerequisites without opening the app.

## A different Windows computer

1. Install Python 3.11 or newer from https://www.python.org/downloads/windows/ and enable its PATH option.
2. Open a terminal in this project folder and run: py -3 -m pip install -r requirements.txt
3. Install FFmpeg using the Windows builds linked from https://ffmpeg.org/download.html and add its bin directory to PATH. Open a new terminal after changing PATH.
4. Run CHECK_SETUP.cmd, then START_ONCOBREATH_PACE.cmd.

The model files and JavaScript libraries are included. After installation, the demonstration runs locally without internet access. It uses saved files and requires no camera or live microphone.

On macOS or Linux, install the same Python packages and FFmpeg, then run python3 run_oncobreath.py. The Windows CMD files are optional shortcuts.

## Demonstration

Select the retrained model. Use the three included teaching examples in order: matching pace, above teaching pace, generated background. Each example runs through the same audio conversion and trained model. Then upload a personal test file if requested. The model analyses the first 30 seconds of files lasting at least 30 seconds.

Share the model link and private project files only with the instructor. Personal recordings stay inside the group and instructor and are deleted after assessment finalisation.
