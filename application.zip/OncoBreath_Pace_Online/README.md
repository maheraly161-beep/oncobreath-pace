# OncoBreath Pace

Saved-audio educational prototype for physiotherapy in oncology rehabilitation. The server creates the fixed 30-second rhythm image, and the frozen Teachable Machine models classify it in the visitor's browser. No camera or live microphone is used.

## Deploy on Render

1. Publish this folder as the root of a new GitHub repository. A private source repository is suitable; the deployed app can have a public URL.
2. In the Render dashboard choose **New > Blueprint** and connect that repository.
3. Render reads `render.yaml`. Review the single **Free** Docker web service, then deploy the Blueprint. No database or paid service is declared.
4. Wait for the service to become **Live**, then open its HTTPS URL.
5. Select the retrained model, expand Included teaching examples, and run matching, above-target and background. Check the displayed result for each class.

Alternatively choose **New > Web Service**, select the repository, set **Docker** as the runtime and **Free** as the instance type, and use `/api/status` as the health-check path. The Dockerfile supplies the start command and `0.0.0.0:10000` defaults.

The Free service can sleep after 15 minutes of inactivity; the next visit can take about a minute to wake it. Open the app before the presentation. See https://render.com/docs/free and https://render.com/docs/infrastructure-as-code.

## Local preview

With Python 3.11+, the packages in `requirements.txt`, and FFmpeg installed, run `START_ONCOBREATH_PACE.cmd` on Windows. It opens http://127.0.0.1:8767/.

For a temporary online preview of **this folder**, run the app on an unused port and use a Cloudflare Quick Tunnel to that port. Keep both processes running. Do not tunnel an older assessment folder: that folder contains private files. The temporary URL is printed by `cloudflared` and changes when the tunnel is recreated. See https://developers.cloudflare.com/tunnel/get-started/quick-tunnels/.

## Data handling

This publication folder excludes personal student recordings, peer evaluations, reports, student IDs and private case evidence. It includes licensed public teaching examples, held-out public-dataset images and the two frozen model exports.

Visitor audio is uploaded to the preview server for conversion and deleted after conversion. The classification is computed in the browser. Evaluation summaries are returned to the current visitor without writing result files to the server. The app is an educational prototype and is not a validated clinical device.

Dataset sources and licence information are in `LICENSES.txt` and `app/samples/provenance.txt`.
