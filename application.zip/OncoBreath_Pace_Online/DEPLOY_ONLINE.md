# Online deployment steps

Use the instructions in README.md. Upload only this Online folder to a new GitHub repository, then deploy it from Render as a Docker Web Service or Blueprint. Do not upload the full assessment ZIP.

To use a temporary tunnel on this computer without clashing with an older app, start this copy on port 8787:

```text
START_ONCOBREATH_PACE.cmd --port 8787
cloudflared tunnel --url http://127.0.0.1:8787
```

Run the two commands in separate terminal windows. Share the generated HTTPS URL and keep both windows open. This is a temporary testing link, rather than the permanent Render submission URL.
