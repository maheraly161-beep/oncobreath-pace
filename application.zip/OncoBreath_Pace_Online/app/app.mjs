import {AnalysisState} from '/app/state.mjs';
const labels=['Matches teaching pace','Above teaching pace','Non-breathing or unusable'];
const state=new AnalysisState();const $=id=>document.getElementById(id);const status=text=>$('status').textContent=text;
function render(){
  for(const id of ['model','audio','split'])$(id).disabled=!!state.busy;
  for(const id of ['analyse','evaluate','demoMatch','demoAbove','demoBackground'])$(id).disabled=!!state.busy||!state.model;
  $('scores').replaceChildren();
  if(!state.result){$('result').textContent='Waiting for a recording';$('analysisMeta').textContent='';$('rhythm').hidden=true;$('rhythm').removeAttribute('src');return;}
  const {scores,image,modelName,fileName}=state.result;const best=scores.indexOf(Math.max(...scores));
  $('result').textContent=(scores[best]<.75?'Uncertain — ':'')+labels[best];
  $('analysisMeta').textContent=`Analysed file: ${fileName}. Model: ${modelName}.`;
  $('rhythm').src=image;$('rhythm').hidden=false;
  labels.forEach((label,i)=>{const row=document.createElement('div');row.className='row';const name=document.createElement('span');name.textContent=label;const pc=document.createElement('span');pc.className='percent';pc.textContent=(100*scores[i]).toFixed(1)+'%';const bar=document.createElement('div');bar.className='bar';const fill=document.createElement('div');fill.className='fill';fill.style.width=100*scores[i]+'%';bar.append(fill);row.append(name,pc,bar);$('scores').append(row);});
}
async function fetchModel(name){const model=await tmImage.load(`/model/${name}/export/model.json`,`/model/${name}/export/metadata.json`);if(JSON.stringify(model.getClassLabels())!==JSON.stringify(labels))throw Error('Exported class order does not match this application');return model;}
async function loadModel(){const name=$('model').value,token=state.startLoad(name);render();status('Loading model…');try{const model=await fetchModel(name);if(state.finishLoad(token,model))status('Model ready — select an audio file');}catch(e){if(state.failLoad(token,e.message))status('Model unavailable: '+e.message);}render();}
function loadImage(src){return new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>resolve(image);image.onerror=()=>reject(Error('Unable to load the rhythm image'));image.src=src;});}
async function predict(classifier,image){const predictions=await classifier.predict(image,false);const scores=labels.map(label=>predictions.find(p=>p.className===label)?.probability);if(scores.some(s=>!Number.isFinite(s)))throw Error('Invalid model output');return scores;}
$('model').onchange=loadModel;
$('audio').onchange=()=>{state.changeFile($('audio').files[0]?.name||'');render();status('File changed — analyse to obtain a new result');};
async function analyseSource(name,readAudio){
  if(state.busy)return;state.changeFile(name);render();
  let op;try{op=state.begin('analysis');render();status('Preparing the first 30 seconds…');const file=await readAudio();const response=await fetch('/api/image',{method:'POST',body:file});const data=await response.json();if(!response.ok)throw Error(data.error);const image=await loadImage(data.png);const scores=await predict(op.classifier,image);if(state.finishAnalysis(op,scores,data.png))status('Analysis complete — educational output');}catch(e){if(op)state.fail(op,e.message);status(e.message);}finally{render();}
}
$('analyse').onclick=async()=>{if(state.busy)return;const file=$('audio').files[0];if(!file){state.changeFile('');render();return status('Choose an audio file first');}await analyseSource(file.name,async()=>file);};
for(const [id,name] of [['demoMatch','matches_teaching_pace.wav'],['demoAbove','above_teaching_pace.wav'],['demoBackground','generated_background.wav']])$(id).onclick=async()=>{if(state.busy)return;$('audio').value='';await analyseSource(name,async()=>{const response=await fetch('/app/samples/'+name);if(!response.ok)throw Error('Teaching example unavailable');return response.blob();});};
async function evaluate(classifier,model,split){
  const response=await fetch('/api/evaluation?split='+split);if(!response.ok)throw Error('Evaluation set unavailable');const rows=await response.json(),results=[];
  for(let i=0;i<rows.length;i++){const image=await loadImage(rows[i].image);results.push({id:rows[i].id,scores:await predict(classifier,image)});$('evalStatus').textContent=`${model}, ${split}: ${i+1}/${rows.length}`;await tf.nextFrame();}
  const saved=await fetch('/api/evaluation-summary',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model,split,results})});const metrics=await saved.json();if(!saved.ok)throw Error(metrics.error);$('metrics').textContent=JSON.stringify(metrics,null,2);
}
$('evaluate').onclick=async()=>{
  if(state.busy)return;let op;try{op=state.begin('evaluation');render();$('metrics').textContent='';await evaluate(op.classifier,op.modelName,$('split').value);state.finish(op);$('evalStatus').textContent='Evaluation complete — session results shown below';}catch(e){if(op)state.fail(op,e.message);$('evalStatus').textContent=e.message;}finally{render();}
};
loadModel();
