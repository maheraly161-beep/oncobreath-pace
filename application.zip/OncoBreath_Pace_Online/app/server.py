"""Public educational preview. Uploaded audio is temporary; inference runs in-browser."""
import argparse, base64, csv, hashlib, io, json, mimetypes, os, tempfile, threading, webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote
from representation import decode_audio, rhythm_image
ROOT=Path(__file__).resolve().parent.parent
LIMIT=20*1024*1024
CACHE=ROOT/'app/.cache';CACHE.mkdir(exist_ok=True)
LABELS=['Matches teaching pace','Above teaching pace','Non-breathing or unusable']
CONVERSIONS=threading.BoundedSemaphore(2)
PUBLIC_APP_FILES={'app/index.html','app/app.mjs','app/state.mjs','app/vendor/tf.min.js','app/vendor/teachablemachine-image.min.js','app/samples/matches_teaching_pace.wav','app/samples/above_teaching_pace.wav','app/samples/generated_background.wav','app/samples/provenance.txt','LICENSES.txt'}

def public_file(relative):
    p=(ROOT/relative).resolve()
    if not p.is_relative_to(ROOT):raise FileNotFoundError('Not found')
    model_files={f'model/{model}/export/{name}' for model in ['baseline','retrained'] for name in ['model.json','metadata.json','weights.bin']}
    dataset_image=relative.startswith('data/images/') and p.is_relative_to(ROOT/'data/images') and p.suffix=='.png'
    if relative not in PUBLIC_APP_FILES and relative not in model_files and not dataset_image:raise FileNotFoundError('Not found')
    if not p.is_file():raise FileNotFoundError('Not found')
    return p

def convert_upload(data):
    if not data:raise ValueError('Choose a non-empty audio file')
    if len(data)>LIMIT:raise ValueError('The maximum audio file size is 20 MB')
    if not CONVERSIONS.acquire(blocking=False):raise ValueError('The preview is busy. Please try again in a moment.')
    try:
        with tempfile.TemporaryDirectory(dir=CACHE) as tmp:
            path=Path(tmp)/'audio';path.write_bytes(data);x,sr=decode_audio(path)
            im=rhythm_image(x,sr);buf=io.BytesIO();im.save(buf,format='PNG');return buf.getvalue()
    finally:CONVERSIONS.release()

def entries(split):
    if split not in ['development','test','development_noise','test_noise']:raise ValueError('Invalid evaluation split')
    noisy=split.endswith('_noise');base=split.removesuffix('_noise')
    with (ROOT/'data/manifest.csv').open(encoding='utf-8') as f:
        rows=list(csv.DictReader(f))
    return [{**r,'image':'/'+r['path']} for r in rows if r['split']==base and (r['variant']==('challenge_0dB' if noisy else 'original') or r['generated']=='True')]

def summarise_evaluation(payload):
    if not isinstance(payload,dict):raise ValueError('Invalid evaluation request')
    model=payload.get('model');split=payload.get('split')
    if model not in ['baseline','retrained']:raise ValueError('Invalid model')
    expected={r['id']:r for r in entries(split)};results=payload.get('results',[])
    if len(results)!=len(expected) or len({r['id'] for r in results})!=len(expected):raise ValueError('Incomplete or duplicated evaluation')
    cm=[[0]*3 for _ in range(3)];clean=[]
    for r in results:
        source=expected[r['id']];scores=r['scores']
        if len(scores)!=3 or any(not isinstance(s,(int,float)) or not 0<=s<=1 for s in scores):raise ValueError('Invalid model scores')
        if abs(sum(scores)-1)>.001:raise ValueError('Invalid probability sum')
        predicted=max(range(3),key=lambda i:scores[i]);truth=int(source['class_index']);cm[truth][predicted]+=1
        clean.append({'id':r['id'],'participant':source['participant'],'expected':LABELS[truth],'predicted':LABELS[predicted],'confidence':max(scores),'correct':truth==predicted,'scores':scores})
    recalls=[cm[i][i]/sum(cm[i]) for i in range(3)]
    export=ROOT/f'model/{model}/export'
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in export.iterdir() if p.is_file()}
    summary={'model':model,'split':split,'runtime':'Official @teachablemachine/image 0.8.5 with TensorFlow.js 4.22.0; model.predict(image,false)','n':len(clean),'correct':sum(r['correct'] for r in clean),'accuracy':sum(r['correct'] for r in clean)/len(clean),'labels':LABELS,'confusion_matrix':cm,'class_recall':dict(zip(LABELS,recalls)),'balanced_accuracy':sum(recalls)/3,'human_participants':len({r['participant'] for r in clean if r['participant']!='none'}),'generated_non_target':sum(r['participant']=='none' for r in clean),'weights_sha256':hashes,'external_classmate_test':False}
    summary['saved_to_server']=False
    return summary

class Handler(BaseHTTPRequestHandler):
    def setup(self):
        super().setup();self.connection.settimeout(30)
    def send(self,status,body,typ='application/json'):
        if not isinstance(body,bytes):body=json.dumps(body).encode()
        self.send_response(status);self.send_header('Content-Type',typ);self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Permissions-Policy','camera=(), microphone=()');self.end_headers()
        for start in range(0,len(body),65536):self.wfile.write(body[start:start+65536])
    def do_GET(self):
        u=urlparse(self.path)
        try:
            if u.path=='/api/status':return self.send(200,{'camera':False,'microphone':False,'labels':LABELS,'models':{m:(ROOT/f'model/{m}/export/model.json').exists() for m in ['baseline','retrained']}})
            if u.path=='/api/evaluation':return self.send(200,entries(parse_qs(u.query).get('split',['development'])[0]))
            relative=unquote(u.path).lstrip('/') or 'app/index.html'
            if relative=='index.html':relative='app/index.html'
            p=public_file(relative)
            return self.send(200,p.read_bytes(),mimetypes.guess_type(p.name)[0] or 'application/octet-stream')
        except (FileNotFoundError,ValueError):self.send(404,{'error':'Not found'})
    def do_POST(self):
        try:
            size=int(self.headers.get('Content-Length',0))
            if size<=0 or size>LIMIT:raise ValueError('Choose a file of 1 byte to 20 MB')
            body=self.rfile.read(size)
            if len(body)!=size:raise ValueError('The upload was incomplete. Please try again.')
            if self.path not in ['/api/image','/api/evaluation-summary']:return self.send(404,{'error':'Not found'})
            if self.path=='/api/image':return self.send(200,{'png':'data:image/png;base64,'+base64.b64encode(convert_upload(body)).decode()})
            if self.path=='/api/evaluation-summary':return self.send(200,summarise_evaluation(json.loads(body)))
            self.send(404,{'error':'Not found'})
        except (ValueError,KeyError,TypeError) as e:self.send(400,{'error':str(e)})
    def log_message(self,*args):pass

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--open-browser',action='store_true');parser.add_argument('--port',type=int,default=int(os.environ.get('PORT','8766')));parser.add_argument('--host',default=os.environ.get('HOST','127.0.0.1'));args=parser.parse_args()
    url=f'http://127.0.0.1:{args.port}'
    try:server=ThreadingHTTPServer((args.host,args.port),Handler)
    except OSError:
        from urllib.request import urlopen
        try:
            state=json.load(urlopen(url+'/api/status',timeout=2))
            if state.get('labels')!=LABELS:raise RuntimeError('Port occupied by another service')
            webbrowser.open(url);raise SystemExit(0)
        except Exception:raise SystemExit('Port unavailable. Close the other service or use --port.')
    if args.open_browser:threading.Timer(.5,lambda:webbrowser.open(url)).start()
    print(f'OncoBreath Pace ready at {url}; file upload only',flush=True);server.serve_forever()
