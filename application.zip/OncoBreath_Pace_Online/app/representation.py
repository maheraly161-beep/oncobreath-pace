import subprocess
import numpy as np
from PIL import Image, ImageDraw
def decode_audio(path):
    try:
        p = subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-protocol_whitelist', 'file,pipe', '-i', str(path), '-ac', '1', '-ar', '8000', '-t', '60', '-f', 'f32le', 'pipe:1'], capture_output=True, timeout=20)
    except subprocess.TimeoutExpired:
        raise ValueError('Audio conversion took too long. Please try another file.') from None
    if p.returncode:
        raise ValueError('Cannot decode this audio file')
    return (np.frombuffer(p.stdout, dtype='<f4').copy(), 8000)

def rhythm_image(samples, sample_rate):
    """No labels or rate estimates are supplied. Axes are identical for all inputs."""
    x = np.asarray(samples, dtype=np.float64)
    if sample_rate <= 0 or len(x) < sample_rate * 29.5:
        raise ValueError('Please provide at least 30 seconds of audio')
    x = np.pad(x[:sample_rate * 30], (0, max(0, sample_rate * 30 - len(x))))
    if not np.isfinite(x).all():
        raise ValueError('Invalid audio samples')
    size = sample_rate // 20
    e = np.sqrt(np.mean(x[:600 * size].reshape(600, size) ** 2, axis=1))
    scale = max(float(np.percentile(e, 99)), 1e-12)
    e = np.clip(e / scale, 0, 1)
    smooth = np.convolve(np.pad(e, (2, 2), mode='edge'), np.ones(5) / 5, mode='valid')
    centred = smooth - smooth.mean()
    ac = np.correlate(centred, centred, 'full')[599:]
    ac = ac / max(float(ac[0]), 1e-12)
    ps = np.abs(np.fft.rfft(centred * np.hanning(600), n=4096)) ** 2
    freqs = np.fft.rfftfreq(4096, 1 / 20)
    fi = np.linspace(0.05, 1, 212)
    p = np.interp(fi, freqs, ps)
    p = p / max(float(p.max()), 1e-12)
    im = Image.new('RGB', (224, 224), (10, 18, 28))
    d = ImageDraw.Draw(im)
    for y in [71, 145, 218]:
        d.line((6, y, 218, y), fill=(65, 80, 90), width=1)

    def line(v, top, height, col):
        xx = np.linspace(6, 218, len(v))
        yy = top + height * (1 - np.clip(v, 0, 1))
        d.line(list(zip(xx, yy)), fill=col, width=2)
    line(smooth, 6, 62, (101, 228, 209))
    line(p, 81, 54, (255, 201, 106))
    line(np.maximum(ac[20:201], 0), 155, 54, (157, 183, 255))
    return im
