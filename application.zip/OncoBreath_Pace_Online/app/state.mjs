export class AnalysisState {
  constructor(){this.version=0;this.model=null;this.modelName='baseline';this.fileName='';this.busy=null;this.result=null;this.error=null;}
  startLoad(name){if(this.busy&&this.busy!=='loading')throw Error('Application is busy');this.modelName=name;this.model=null;this.result=null;this.error=null;this.busy='loading';return ++this.version;}
  finishLoad(token,model){if(token!==this.version)return false;this.model=model;this.busy=null;return true;}
  failLoad(token,error){if(token!==this.version)return false;this.model=null;this.busy=null;this.result=null;this.error=error;return true;}
  changeFile(name){if(this.busy)throw Error('Application is busy');this.fileName=name;this.result=null;this.error=null;}
  begin(kind){if(this.busy)throw Error('Application is busy');if(!this.model)throw Error('The selected trained model is unavailable');this.busy=kind;this.result=null;this.error=null;return {token:++this.version,kind,classifier:this.model,modelName:this.modelName,fileName:this.fileName};}
  finishAnalysis(op,scores,image){if(op.token!==this.version||this.busy!=='analysis')return false;this.result={scores,image,modelName:op.modelName,fileName:op.fileName};this.busy=null;return true;}
  finish(op){if(op.token!==this.version)return false;this.busy=null;return true;}
  fail(op,error){if(op.token!==this.version)return false;this.result=null;this.error=error;this.busy=null;return true;}
}
