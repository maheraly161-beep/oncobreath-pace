"""Check the local package and launch the saved-audio demonstration."""
import argparse,importlib.util,json,shutil,subprocess,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def check_setup():
    missing=[]
    if sys.version_info<(3,11):missing.append('Python 3.11 or newer')
    for module,title in [('numpy','NumPy'),('PIL','Pillow')]:
        if importlib.util.find_spec(module) is None:missing.append(title)
    if not shutil.which('ffmpeg'):missing.append('FFmpeg')
    models=['baseline','retrained']
    if not all((ROOT/'model'/model/'export'/file).is_file() for model in models for file in ['model.json','metadata.json','weights.bin']):missing.append('model files')
    if not all((ROOT/'app'/file).is_file() for file in ['server.py','representation.py','index.html','app.mjs','state.mjs']):missing.append('application files')
    return {'status':'ready' if not missing else 'setup needed','python':sys.version.split()[0],'models':models,'missing':missing,'camera':False,'live_microphone':False}

def main():
    parser=argparse.ArgumentParser(description='OncoBreath Pace local saved-audio demonstration')
    parser.add_argument('--check',action='store_true',help='Report setup status without starting a browser or server')
    parser.add_argument('--port',type=int,default=8767)
    parser.add_argument('--no-browser',action='store_true')
    args=parser.parse_args();status=check_setup()
    if args.check:
        print(json.dumps(status,indent=2));return 0 if not status['missing'] else 1
    if status['missing']:
        print('OncoBreath Pace needs: '+', '.join(status['missing']))
        print('See SETUP.md in this folder for installation steps.')
        return 1
    command=[sys.executable,str(ROOT/'app/server.py'),'--port',str(args.port)]
    if not args.no_browser:command.append('--open-browser')
    return subprocess.call(command,cwd=ROOT)

if __name__=='__main__':raise SystemExit(main())
