@echo off
setlocal
cd /d "%~dp0"
if exist "%~dp0runtime\python\python.exe" (
    "%~dp0runtime\python\python.exe" "%~dp0run_oncobreath.py" %*
    goto :done
)
if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" (
    "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" "%~dp0run_oncobreath.py" %*
    goto :done
)
py -3 -c "import sys; raise SystemExit(sys.version_info.__lt__((3,11)))" >nul 2>nul
if not errorlevel 1 (
    py -3 "%~dp0run_oncobreath.py" %*
    goto :done
)
python -c "import sys; raise SystemExit(sys.version_info.__lt__((3,11)))" >nul 2>nul
if not errorlevel 1 (
    python "%~dp0run_oncobreath.py" %*
    goto :done
)
echo Python 3.11 or newer is required. Follow SETUP.md in this folder.
exit /b 1
:done
exit /b %errorlevel%

