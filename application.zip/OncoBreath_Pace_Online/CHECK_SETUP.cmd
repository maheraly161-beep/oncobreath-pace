@echo off
call "%~dp0START_ONCOBREATH_PACE.cmd" --check
pause
